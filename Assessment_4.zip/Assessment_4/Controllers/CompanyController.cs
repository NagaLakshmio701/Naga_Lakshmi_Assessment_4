﻿using Microsoft.AspNetCore.Mvc;
using Assessment_4.Entities;

namespace Assessment_4.Controllers
{
    public class CompanyController : Controller
    {

        private readonly StudentCompanyContext CompanyContext;

        public CompanyController()
        {
            CompanyContext =new StudentCompanyContext();
        }

        // 1. AddCompany
        // 
        [HttpGet]

        [Route ("AddCompany")]
        public IActionResult AddCompany()
        {
            return View();
        }

        [HttpPost]

        public IActionResult AddCompany(Company companies)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    CompanyContext.Companies.Add(companies);
                    CompanyContext.SaveChanges();
                    return RedirectToAction("GetAllCompanies");

                }


                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //2. List out all the Companies.

        [Route ("GetAllCompanies")]
        public IActionResult GetAllCompanies()
        {
            var companuy = CompanyContext.Companies;
            return View(companuy);
            
        }



    }
}
