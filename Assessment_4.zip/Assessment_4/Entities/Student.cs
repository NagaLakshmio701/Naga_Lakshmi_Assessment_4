﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Assessment_4.Entities;

public partial class Student
{
    [Required(ErrorMessage = "ID IS REQUIRED")]

    public int StudentId { get; set; }

    [Required(ErrorMessage = "NAME IS REQUIRED")]

    public string? Name { get; set; }

    [Required(ErrorMessage = "QUALIFICATION IS REQUIRED")]

    public string? Qualification { get; set; }

    [Required(ErrorMessage = "SKILL IS REQUIRED")]

    public string? Skill { get; set; }
}
