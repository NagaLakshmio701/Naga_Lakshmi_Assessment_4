﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Assessment_4.Entities;

public partial class Company
{
    [Required (ErrorMessage ="ID IS REQUIRED")]
    public int CompanyId { get; set; }

    [Required(ErrorMessage = "NAME IS REQUIRED")]

    public string? Name { get; set; }

    [Required(ErrorMessage = "City IS REQUIRED")]


    public string? City { get; set; }

    [Required(ErrorMessage = "Address IS REQUIRED")]


    public string? Address { get; set; }
}
