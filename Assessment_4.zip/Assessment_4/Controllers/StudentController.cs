﻿using Assessment_4.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assessment_4.Controllers
{
    public class StudentController : Controller
    {


        private readonly StudentCompanyContext student;

        public StudentController()
        {
            student = new StudentCompanyContext();
        }

        // 3. Add Student

        [HttpGet]
        [Route ("AddStudent")]
        public IActionResult AddStudent()
        {
            return View();
        }

        [HttpPost]

        public IActionResult AddStudent(Student Students)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    student.Students.Add(Students);
                    student.SaveChanges();
                    return RedirectToAction("GetAllStudents");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }


        public IActionResult GetAllStudents()
        {
            var Student = student.Students;
            return View(Student);

        }


        // 4. Get Student details by studentId 

        [Route("GetStudentByID/{id}")]
        public IActionResult GetStudenById(int id)
        {
            try
            {
                var Student = student.Students.SingleOrDefault(s => s.StudentId == id);
                return View(Student);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        // 5. Update Student skill,qualification by  id

        [HttpGet]

        [Route ("UpdateById/{id}")]
        public IActionResult Update(int id)
        {
            try
            {
                var Student = student.Students.SingleOrDefault(s => s.StudentId == id);
                return View(Student);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
                
            }
            
        }

        [HttpPost]

        [Route("UpdateById/{id}")]


        public IActionResult Update(Student Student)
        {

            try
            {
                student.Students.Update(Student);
                student.SaveChanges();
                return RedirectToAction("GetAllStudents");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
               
            }
                
        }

        // 6. Delete a Student by  id 

        [HttpGet]

        [Route ("DeleteById/{id}")]
        public IActionResult Delete(int id)
        {
            var Student=student.Students.SingleOrDefault(s=>s.StudentId==id);
            return View(Student);
        }

        [HttpPost]

        [Route ("DeleteById/{id}")]

        public IActionResult Delete(Student Student)
        {
            try
            {
                student.Students.Remove(Student);
                student.SaveChanges();
                return RedirectToAction("GetAllStudents");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }


    }
}
